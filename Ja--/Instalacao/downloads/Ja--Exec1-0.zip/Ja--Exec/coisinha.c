#include<stdio.h>
void main(void) { ; 
 int i = 0 ; 
 while ( i  < 10 ) { ; 
 printf("Repeticao numero ") ; 
 printf("%d",i) ; 
 printf("\n") ; 
i = i  + 1 ; 
;} ; 
char sair_CMPLR[500]; printf("digite qualquer coisa para sair"); scanf("%s",&sair_CMPLR) ;} ; 
